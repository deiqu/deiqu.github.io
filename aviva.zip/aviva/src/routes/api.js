const express = require('express');
const router = express.Router();
const { getSedes, getEspecialidades, getDoctores } = require('../controllers/dataController');

// Rutas para obtener datos
router.get('/sedes', getSedes);
router.get('/especialidades', getEspecialidades);
router.get('/doctores', getDoctores);

module.exports = router;