const sedes = [
  { id: 1, name: 'Sede Central' },
  { id: 2, name: 'Sede Norte' },
];

function getSedes(req, res) {
  res.json(sedes);
}

const especialidades = [
  { id: 1, name: 'Cardiología' },
  { id: 2, name: 'Dermatología' },
];

function getEspecialidades(req, res) {
  res.json(especialidades);
}

const doctores = [
  { id: 1, name: 'Dr. Juan Pérez', especialidadId: 1, sedeId: 1 },
  { id: 2, name: 'Dra. Ana García', especialidadId: 2, sedeId: 2 },
  { id: 3, name: 'Dr. Luis Rodríguez', especialidadId: 1, sedeId: 2 },
  { id: 4, name: 'Dra. María López', especialidadId: 2, sedeId: 1 },
  { id: 5, name: 'Dr. Diego Miera', especialidadId: 2, sedeId: 1 },
  { id: 6, name: 'Dra. Keysi Abigaid', especialidadId: 2, sedeId: 1 },
  { id: 7, name: 'Dra. Elsa Bernal', especialidadId: 2, sedeId: 1 },
  { id: 8, name: 'Dra. Alicia Carmen', especialidadId: 2, sedeId: 1 },
];

function getEspecialidadName(especialidadId) {
  const especialidad = especialidades.find(e => e.id === especialidadId);
  return especialidad ? especialidad.name : 'Especialidad no encontrada';
}

function getSedeName(sedeId) {
  const sede = sedes.find(s => s.id === sedeId);
  return sede ? sede.name : 'Sede no encontrada';
}

function getDoctores(req, res) {
  const sede = parseInt(req.query.sede);
  const especialidad = parseInt(req.query.especialidad);
  
  const filteredDoctores = doctores.filter(doctor => {
      return doctor.sedeId === sede && doctor.especialidadId === especialidad;
  }).map(doctor => ({
      id: doctor.id,
      name: doctor.name,
      especialidad: getEspecialidadName(doctor.especialidadId),
      sede: getSedeName(doctor.sedeId)
  }));

  res.json(filteredDoctores);
}

module.exports = {
  getSedes,
  getEspecialidades,
  getDoctores
};
