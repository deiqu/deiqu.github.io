function getParameterByName(name, url = window.location.href) {
    name = name.replace(/[\\[\\]]/g, '\\\\$&');
    const regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)');
    const results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\\+/g, ' '));
}

document.addEventListener('DOMContentLoaded', function() {
    const doctorName = decodeURIComponent(getParameterByName('doctorName'));

    console.log('Doctor Name:', doctorName);

    const doctorInfoContainer = document.getElementById('doctor-info');
    doctorInfoContainer.innerHTML = `
        <h1 class="text-3xl font-bold">Selecciona la fecha y hora de la cita con ${doctorName}</h1>
    `;

    // Capturar los elementos del formulario
    const appointmentForm = document.getElementById('appointment-form');
    const appointmentDateInput = document.getElementById('appointment-date');
    const appointmentTimeInput = document.getElementById('appointment-time');

    // Función para verificar si una fecha es un día laboral (lunes a viernes)
    function isWeekday(date) {
        const day = date.getDay();
        return day !== 0 && day !== 6; // 0 = Domingo, 6 = Sábado
    }

    // Función para verificar si una hora está dentro del horario laboral (8:00 - 17:00)
    function isBusinessHour(time) {
        const hour = time.getHours();
        return hour >= 8 && hour < 17;
    }

    // Validación al enviar el formulario
    appointmentForm.addEventListener('submit', function(event) {
        const selectedDate = new Date(appointmentDateInput.value);
        const selectedTime = new Date(`2000-01-01T${appointmentTimeInput.value}`);

        if (!isWeekday(selectedDate)) {
            alert('Por favor elige un día laboral (lunes a viernes).');
            event.preventDefault();
        } else if (!isBusinessHour(selectedTime)) {
            alert('Las citas están disponibles de 8:00 AM a 5:00 PM.');
            event.preventDefault();
        } else {
            // Redirigir a la página de rellenar datos con los parámetros en la URL
            const newUrl = `rellenar-datos.html?doctorName=${encodeURIComponent(doctorName)}&date=${appointmentDateInput.value}&time=${appointmentTimeInput.value}`;
            window.location.href = newUrl;
        }
    });
});
