document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const sedeId = urlParams.get('sede');
    const especialidadId = urlParams.get('especialidad');
    const doctorList = document.getElementById('doctor-list');

    if (sedeId && especialidadId) {
        fetch(`http://localhost:5000/api/doctores?sede=${sedeId}&especialidad=${especialidadId}`)
            .then(response => response.json())
            .then(data => {
                if (data.length > 0) {
                    data.forEach(doctor => {
                        const doctorItem = document.createElement('div');
                        doctorItem.className = 'p-4 border border-gray-300 rounded-md mb-4';
                        doctorItem.innerHTML = `
                            <h2 class="text-xl font-bold">${doctor.name}</h2>
                            <p class="text-gray-700">Especialidad: ${doctor.especialidad}</p>
                            <p class="text-gray-700">Sede: ${doctor.sede}</p>
                            <button class="bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700" data-doctor-id="${doctor.id}" data-doctor-name="${doctor.name}" data-doctor-gender="${getDoctorGender(doctor.name)}">
                                Agendar Cita
                            </button>
                        `;
                        doctorItem.querySelector('button').addEventListener('click', () => {
                            mostrarDisponibilidad(doctor);
                        });
                        doctorList.appendChild(doctorItem);
                    });
                } else {
                    doctorList.innerHTML = '<p class="text-gray-700">No hay doctores disponibles para esta especialidad en la sede seleccionada.</p>';
                }
            })
            .catch(error => console.error('Error fetching doctores:', error));
    } else {
        doctorList.innerHTML = '<p class="text-gray-700">No se han proporcionado los parámetros necesarios.</p>';
    }

    function getDoctorGender(name) {
        if (name.toLowerCase().includes('dra.')) {
            return 'la';
        } else if (name.toLowerCase().includes('dr.')) {
            return 'el';
        } else {
            return 'el doctor';
        }
    }

    function mostrarDisponibilidad(doctor) {
        const doctorGender = getDoctorGender(doctor.name);
        const url = `disponibilidad.html?doctorId=${doctor.id}&doctorName=${encodeURIComponent(doctor.name)}&doctorGender=${doctorGender}&doctorEspecialidad=${encodeURIComponent(doctor.especialidad)}&doctorSede=${encodeURIComponent(doctor.sede)}`;
        window.location.href = url;
    }
    
});
