document.addEventListener('DOMContentLoaded', () => {
    const sedeSelect = document.getElementById('sede');
    const especialidadSelect = document.getElementById('especialidad');
    const form = document.getElementById('appointment-form');

    // Fetch Sedes
    fetch('http://localhost:5000/api/sedes')
        .then(response => response.json())
        .then(data => {
            data.forEach(sede => {
                const option = document.createElement('option');
                option.value = sede.id;
                option.textContent = sede.name;
                sedeSelect.appendChild(option);
            });
        })
        .catch(error => console.error('Error fetching sedes:', error));

    // Fetch Especialidades
    fetch('http://localhost:5000/api/especialidades')
        .then(response => response.json())
        .then(data => {
            data.forEach(especialidad => {
                const option = document.createElement('option');
                option.value = especialidad.id;
                option.textContent = especialidad.name;
                especialidadSelect.appendChild(option);
            });
        })
        .catch(error => console.error('Error fetching especialidades:', error));

    // Handle form submission
    form.addEventListener('submit', (event) => {
        event.preventDefault();
        const sedeId = sedeSelect.value;
        const especialidadId = especialidadSelect.value;
        if (sedeId && especialidadId) {
            window.location.href = `citas.html?sede=${sedeId}&especialidad=${especialidadId}`;
        } else {
            alert('Por favor, selecciona una sede y una especialidad.');
        }
    });
});